const batches = [
  { id: "BCH-VAC-2045", name: "mRNA Vaccine Vial", tempMin: 2, tempMax: 8, supplier: "GulfBio Pharma", expiry: "2026-04-18", locations: ["Dubai Central Hospital", "Al Ain Vaccine Clinic"] },
  { id: "BCH-INS-1180", name: "Insulin Glargine Pen", tempMin: 2, tempMax: 8, supplier: "MedNova Labs", expiry: "2026-01-11", locations: ["Sharjah Oncology Center", "City Care Pharmacy"] },
  { id: "BCH-ONC-7721", name: "Oncology Biologic Pack", tempMin: 2, tempMax: 6, supplier: "OncoLife UAE", expiry: "2025-12-02", locations: ["Abu Dhabi Oncology Wing"] },
  { id: "BCH-BLD-5409", name: "Blood Plasma Unit", tempMin: -25, tempMax: -18, supplier: "National Blood Bank", expiry: "2025-11-26", locations: ["Al Ain Blood Bank", "Dubai Central Hospital"] }
];

let shipments = [
  { id: "SHP-24071", batchId: "BCH-VAC-2045", destination: "Dubai Central Hospital Pharmacy", driver: "DXB-Driver-14", sensor: "SEN-TMP-2049", status: "In Transit", temp: 5.2, humidity: 42, eta: "24 min", risk: "Safe" },
  { id: "SHP-24072", batchId: "BCH-ONC-7721", destination: "Sharjah Oncology Center", driver: "SHJ-Driver-03", sensor: "SEN-TMP-1181", status: "Quarantined", temp: 9.4, humidity: 51, eta: "Arrived", risk: "Critical" },
  { id: "SHP-24073", batchId: "BCH-INS-1180", destination: "Abu Dhabi Vaccine Clinic", driver: "AUH-Driver-06", sensor: "SEN-TMP-7720", status: "Prepared", temp: 4.8, humidity: 46, eta: "Awaiting dispatch", risk: "Safe" }
];

let breaches = [
  { id: "BR-9021", shipmentId: "SHP-24072", batchId: "BCH-ONC-7721", severity: "Critical", reading: "9.4°C for 7 minutes", status: "Open", createdAt: "10:18" }
];
let recalls = [];
let audit = [
  "SHP-24072 marked Quarantined by Monitoring Service",
  "BR-9021 alert delivered to QA Officer",
  "BCH-VAC-2045 batch verified during dispatch",
  "Driver DXB-Driver-14 started delivery SHP-24071"
];
let tempSeries = [4.9, 5.1, 5.3, 5.2, 5.0, 5.4, 5.6, 5.1, 5.3, 5.2, 5.5, 5.4];

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

function init() {
  $("#loginForm").addEventListener("submit", event => {
    event.preventDefault();
    $("#loginView").classList.add("hidden");
    $("#appShell").classList.remove("hidden");
    renderAll();
    toast("Access granted", "ColdChainRx compliance console is ready.");
  });

  $$(".nav-item").forEach(button => button.addEventListener("click", () => openPage(button.dataset.page)));
  $$('[data-jump]').forEach(button => button.addEventListener("click", () => openPage(button.dataset.jump)));

  $("#shipmentForm").addEventListener("submit", createShipment);
  $("#simulateReadingBtn").addEventListener("click", simulateReading);
  $("#forceBreachBtn").addEventListener("click", createBreach);
  $("#addBreachBtn").addEventListener("click", createBreach);
  $("#recallForm").addEventListener("submit", issueRecall);
  $("#generateReportBtn").addEventListener("click", () => toast("PDF report generated", "Compliance report file is ready for export."));

  fillSelects();
}

function fillSelects() {
  ["#batchSelect", "#recallBatchSelect"].forEach(id => {
    const select = $(id);
    select.innerHTML = batches.map(batch => `<option value="${batch.id}">${batch.id} · ${batch.name}</option>`).join("");
  });
}

function openPage(pageId) {
  $$(".page").forEach(page => page.classList.remove("active-page"));
  $$(".nav-item").forEach(item => item.classList.toggle("active", item.dataset.page === pageId));
  $("#" + pageId).classList.add("active-page");
  $("#pageTitle").textContent = $(`.nav-item[data-page="${pageId}"]`).textContent;
  renderAll();
}

function renderAll() {
  renderKpis();
  renderShipments();
  renderQaQueue();
  renderTracking();
  renderBreaches();
  renderQuarantine();
  renderRecalls();
  renderReports();
  renderAudit();
  drawTemperatureChart();
}

function renderKpis() {
  $("#kpiActive").textContent = shipments.filter(s => s.status !== "Delivered" && s.status !== "Rejected").length;
  $("#kpiQuarantine").textContent = shipments.filter(s => s.status === "Quarantined").length;
  $("#kpiBreaches").textContent = breaches.filter(b => b.status === "Open").length;
  $("#kpiRecalls").textContent = recalls.filter(r => r.status === "Open").length;
}

function getBatch(batchId) {
  return batches.find(batch => batch.id === batchId);
}

function statusClass(status) {
  if (["Safe", "Prepared", "In Transit", "Delivered", "Released"].includes(status)) return "safe";
  if (["Quarantined", "At Risk", "Pending"].includes(status)) return "warn";
  return "danger";
}

function renderShipments() {
  const cards = shipments.map(shipment => {
    const batch = getBatch(shipment.batchId);
    return `<article class="shipment-card">
      <header><h4>${shipment.id}</h4><span class="status-chip ${statusClass(shipment.status)}">${shipment.status}</span></header>
      <p><b>${batch.name}</b> · ${batch.id}</p>
      <p>${shipment.destination}</p>
      <div class="meta-row"><span class="status-chip ${statusClass(shipment.risk)}">${shipment.risk}</span><span class="status-chip">${shipment.temp}°C</span><span class="status-chip">ETA ${shipment.eta}</span></div>
    </article>`;
  }).join("");
  $("#shipmentCards").innerHTML = cards;
  $("#dispatchList").innerHTML = shipments.map(s => `<div class="record-card"><div><h4>${s.id}</h4><p>${getBatch(s.batchId).name} to ${s.destination}</p></div><span class="status-chip ${statusClass(s.status)}">${s.status}</span></div>`).join("");
}

function renderQaQueue() {
  const queue = breaches.filter(b => b.status === "Open");
  $("#qaQueue").innerHTML = queue.length ? queue.map(b => `<div class="action-item"><strong>${b.id} · ${b.severity}</strong><p>${b.shipmentId} requires QA decision.</p><button class="secondary-btn" onclick="openPage('quarantine')">Review case</button></div>`).join("") : `<div class="action-item"><strong>No urgent QA decisions</strong><p>All shipments are inside acceptable compliance state.</p></div>`;
}

function renderTracking() {
  const selected = shipments[0];
  $("#trackingShipmentTitle").textContent = `${selected.id} · ${getBatch(selected.batchId).name}`;
  $("#trackingDetails").innerHTML = `
    <div class="record-card"><h4>Destination</h4><p>${selected.destination}</p></div>
    <div class="record-card"><h4>Driver</h4><p>${selected.driver}</p></div>
    <div class="record-card"><h4>Current Reading</h4><p>${selected.temp}°C · ${selected.humidity}% RH</p></div>
    <div class="record-card"><h4>Status</h4><p>${selected.status} · ETA ${selected.eta}</p></div>`;
  $("#tempTimeline").innerHTML = tempSeries.map(value => `<span class="temp-point ${value > 8 ? "hot" : ""}">${value.toFixed(1)}°C</span>`).join("");
}

function renderBreaches() {
  $("#breachList").innerHTML = breaches.length ? breaches.map(b => `<div class="record-card">
    <div><h4>${b.id} · ${b.severity}</h4><p>${b.shipmentId} / ${b.batchId} · ${b.reading} · ${b.createdAt}</p></div>
    <div class="record-actions"><button class="secondary-btn" onclick="openPage('quarantine')">Review</button><span class="status-chip ${statusClass(b.status === "Open" ? "Quarantined" : "Released")}">${b.status}</span></div>
  </div>`).join("") : `<div class="record-card"><h4>No breach alerts</h4><p>Sensor stream is currently within approved ranges.</p></div>`;
}

function renderQuarantine() {
  const cases = shipments.filter(s => s.status === "Quarantined" || s.status === "At Risk");
  $("#quarantineList").innerHTML = cases.length ? cases.map(s => `<div class="record-card">
    <div><h4>${s.id} · ${getBatch(s.batchId).name}</h4><p>Temperature history indicates ${s.risk.toLowerCase()} risk. QA justification is required.</p></div>
    <div class="record-actions"><button class="secondary-btn" onclick="qaDecision('${s.id}', 'Released')">Release</button><button class="danger-btn" onclick="qaDecision('${s.id}', 'Rejected')">Reject</button></div>
  </div>`).join("") : `<div class="record-card"><h4>No quarantined shipments</h4><p>There are no pending QA decisions.</p></div>`;
}

function renderRecalls() {
  $("#recallResults").innerHTML = recalls.length ? recalls.map(r => `<div class="record-card">
    <div><h4>${r.id} · ${r.batchId}</h4><p>${r.severity} recall · ${r.locations.join(", ")}</p></div>
    <span class="status-chip danger">${r.status}</span>
  </div>`).join("") : `<div class="record-card"><h4>No recall notice issued</h4><p>Choose a batch and confirm recall to see affected locations.</p></div>`;
}

function renderReports() {
  $("#reportReadingCount").textContent = tempSeries.length * shipments.length;
  $("#reportQuarantineCount").textContent = shipments.filter(s => s.status === "Quarantined").length;
  $("#reportRecallCount").textContent = recalls.length;
}

function renderAudit() {
  $("#auditLog").innerHTML = audit.slice(0, 8).map(item => `<div class="action-item"><strong>${new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}</strong><p>${item}</p></div>`).join("");
}

function createShipment(event) {
  event.preventDefault();
  const batchId = $("#batchSelect").value;
  const shipment = {
    id: `SHP-${Math.floor(25000 + Math.random() * 7000)}`,
    batchId,
    destination: $("#destinationSelect").value,
    driver: $("#driverSelect").value.split(" · ")[0],
    sensor: $("#sensorSelect").value,
    status: "Prepared",
    temp: Number((getBatch(batchId).tempMin + 1.6).toFixed(1)),
    humidity: 44,
    eta: "Awaiting dispatch",
    risk: "Safe"
  };
  shipments.unshift(shipment);
  audit.unshift(`${shipment.id} created for ${shipment.destination}`);
  renderAll();
  toast("Shipment created", `${shipment.id} is ready for dispatch.`);
}

function simulateReading() {
  const shipment = shipments[0];
  const batch = getBatch(shipment.batchId);
  const drift = (Math.random() * 2 - 1) * 0.8;
  const value = Math.max(batch.tempMin - 1, Math.min(batch.tempMax + 1, shipment.temp + drift));
  shipment.temp = Number(value.toFixed(1));
  tempSeries.push(shipment.temp);
  tempSeries = tempSeries.slice(-12);
  audit.unshift(`Sensor ${shipment.sensor} stored reading ${shipment.temp}°C for ${shipment.id}`);
  renderAll();
  toast("Sensor reading stored", `${shipment.id}: ${shipment.temp}°C, ${shipment.humidity}% RH.`);
}

function createBreach() {
  const shipment = shipments.find(s => s.status !== "Rejected") || shipments[0];
  shipment.status = "Quarantined";
  shipment.risk = "Critical";
  shipment.temp = 10.2;
  tempSeries = [...tempSeries.slice(-9), 8.7, 9.5, 10.2];
  const breach = { id: `BR-${Math.floor(9000 + Math.random() * 800)}`, shipmentId: shipment.id, batchId: shipment.batchId, severity: "Critical", reading: `${shipment.temp}°C for 6 minutes`, status: "Open", createdAt: new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}) };
  breaches.unshift(breach);
  audit.unshift(`${breach.id} created and ${shipment.id} moved to Quarantined`);
  renderAll();
  toast("Critical breach detected", `${shipment.id} has been quarantined automatically.`);
}

function qaDecision(shipmentId, decision) {
  const shipment = shipments.find(s => s.id === shipmentId);
  if (!shipment) return;
  shipment.status = decision;
  shipment.risk = decision === "Released" ? "Safe" : "Rejected";
  breaches.filter(b => b.shipmentId === shipmentId).forEach(b => b.status = "Closed");
  audit.unshift(`QA Officer marked ${shipmentId} as ${decision}`);
  renderAll();
  toast("QA decision recorded", `${shipmentId} is now ${decision}.`);
}

function issueRecall(event) {
  event.preventDefault();
  const batchId = $("#recallBatchSelect").value;
  const batch = getBatch(batchId);
  const recall = { id: `RC-${Math.floor(6000 + Math.random() * 900)}`, batchId, severity: $("#recallSeverity").value, reason: $("#recallReason").value, locations: batch.locations, status: "Open" };
  recalls.unshift(recall);
  audit.unshift(`${recall.id} issued for ${batchId}; ${batch.locations.length} affected locations notified`);
  renderAll();
  toast("Recall confirmed", `${batch.locations.length} affected locations were traced and notified.`);
}

function drawTemperatureChart() {
  const canvas = $("#tempCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  const gradient = ctx.createLinearGradient(0, 0, 0, h);
  gradient.addColorStop(0, "rgba(77,225,255,.30)");
  gradient.addColorStop(1, "rgba(77,225,255,0)");
  const min = Math.min(...tempSeries, 0);
  const max = Math.max(...tempSeries, 12);
  const mapY = value => h - 36 - ((value - min) / (max - min)) * (h - 72);
  const mapX = index => 36 + index * ((w - 72) / (tempSeries.length - 1));

  ctx.strokeStyle = "rgba(255,255,255,.09)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const y = 28 + i * 54;
    ctx.beginPath();
    ctx.moveTo(24, y);
    ctx.lineTo(w - 24, y);
    ctx.stroke();
  }

  ctx.beginPath();
  tempSeries.forEach((value, index) => index ? ctx.lineTo(mapX(index), mapY(value)) : ctx.moveTo(mapX(index), mapY(value)));
  ctx.lineTo(mapX(tempSeries.length - 1), h - 30);
  ctx.lineTo(mapX(0), h - 30);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  ctx.beginPath();
  tempSeries.forEach((value, index) => index ? ctx.lineTo(mapX(index), mapY(value)) : ctx.moveTo(mapX(index), mapY(value)));
  ctx.strokeStyle = "#4de1ff";
  ctx.lineWidth = 4;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.stroke();

  tempSeries.forEach((value, index) => {
    ctx.beginPath();
    ctx.arc(mapX(index), mapY(value), value > 8 ? 7 : 5, 0, Math.PI * 2);
    ctx.fillStyle = value > 8 ? "#ff5d6c" : "#34e0a1";
    ctx.fill();
  });

  ctx.fillStyle = "rgba(236,246,255,.72)";
  ctx.font = "700 15px Inter, system-ui";
  ctx.fillText("Temperature readings (°C)", 32, 24);
}

function toast(title, message) {
  const node = document.createElement("div");
  node.className = "toast";
  node.innerHTML = `<strong>${title}</strong><small>${message}</small>`;
  $("#toastHost").appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

init();
