const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  shipments: [
    { id: "SH-2048", medicine: "Influenza Vaccine / Insulin", status: "In Transit", eta: "11:20", type: "warning" },
    { id: "SH-2049", medicine: "Oncology Biologic", status: "Prepared", eta: "13:10", type: "normal" },
    { id: "SH-2050", medicine: "Blood Plasma Units", status: "Quarantined", eta: "Blocked", type: "quarantine" },
    { id: "SH-2051", medicine: "Rapid Insulin", status: "Delivered", eta: "Completed", type: "normal" }
  ],
  audit: [
    ["10:31", "QA Officer", "Breach classified", "SH-2048", "High"],
    ["10:29", "System", "Shipment quarantined", "SH-2048", "Pending QA"],
    ["10:26", "Sensor Gateway", "Temperature breach", "SEN-TMP-8842", "9.8°C"],
    ["09:42", "Driver", "Delivery started", "SH-2048", "In Transit"],
    ["09:15", "Warehouse Manager", "Shipment created", "SH-2048", "Prepared"]
  ],
  chartData: [4.2, 4.4, 4.8, 5.2, 5.6, 6.1, 7.2, 8.1, 8.9, 9.8, 9.4, 8.2, 7.1, 6.4, 5.9]
};

const titles = {
  dashboard: "Dashboard",
  create: "Create Shipment",
  tracking: "Shipment Tracking",
  breach: "Breach Center",
  quarantine: "Quarantine Review",
  recall: "Drug Recall",
  reports: "Reports",
  audit: "Audit Log"
};

function toast(message) {
  const t = $("#toast");
  t.textContent = message;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2600);
}

function navigate(page) {
  $$(".page").forEach(p => p.classList.remove("active"));
  $(`#${page}`).classList.add("active");
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === page));
  $("#pageTitle").textContent = titles[page];
  requestAnimationFrame(drawAllCharts);
}

function renderShipments() {
  $("#shipmentRows").innerHTML = state.shipments.map(s => {
    const cls = s.type === "quarantine" ? "quarantine" : s.type === "warning" ? "recall" : "in-transit";
    return `<tr><td>${s.id}</td><td>${s.medicine}</td><td><span class="status-pill ${cls}">${s.status}</span></td><td>${s.eta}</td></tr>`;
  }).join("");
}

function renderAlerts() {
  $("#priorityAlerts").innerHTML = [
    `<div class="alert-row danger"><strong>SH-2048 · Temperature Excursion</strong>9.8°C detected for 7 minutes. QA review required.</div>`,
    `<div class="alert-row warning"><strong>QC-118 · Quarantine Pending</strong>Hospital receiving is blocked until decision is recorded.</div>`,
    `<div class="alert-row"><strong>Recall RC-077</strong>VAC-24-AZ19 affects three receiving locations.</div>`
  ].join("");
}

function renderAffectedLocations() {
  const locations = [
    ["Sheikh Khalifa Hospital", "112 units", "Notified"],
    ["Rashid Hospital Pharmacy", "64 units", "Acknowledged"],
    ["Al Ain Medical Center", "31 units", "Pending"],
    ["Dubai Pharma Warehouse A", "240 units", "Quarantined"]
  ];
  $("#affectedLocations").innerHTML = locations.map(l => `
    <div class="location-card"><div><strong>${l[0]}</strong><span>${l[1]} affected</span></div><span class="badge ${l[2] === "Pending" ? "warning" : "success"}">${l[2]}</span></div>
  `).join("");
}

function renderAudit() {
  $("#auditRows").innerHTML = state.audit.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("");
}

function drawChart(canvasId, data, min = 2, max = 10) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr;
  canvas.height = (parseInt(canvas.getAttribute("height"), 10) || 220) * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  const w = rect.width;
  const h = canvas.height / dpr;
  ctx.clearRect(0, 0, w, h);

  const pad = 26;
  const x = i => pad + i * ((w - pad * 2) / (data.length - 1));
  const y = v => h - pad - ((v - min) / (max - min)) * (h - pad * 2);

  ctx.strokeStyle = "rgba(255,255,255,.12)";
  ctx.lineWidth = 1;
  [2, 4, 6, 8, 10].forEach(v => {
    ctx.beginPath();
    ctx.moveTo(pad, y(v));
    ctx.lineTo(w - pad, y(v));
    ctx.stroke();
  });

  ctx.strokeStyle = "rgba(255,92,122,.48)";
  ctx.setLineDash([7, 6]);
  ctx.beginPath();
  ctx.moveTo(pad, y(8));
  ctx.lineTo(w - pad, y(8));
  ctx.stroke();
  ctx.setLineDash([]);

  const gradient = ctx.createLinearGradient(0, 0, w, 0);
  gradient.addColorStop(0, "#42e8c9");
  gradient.addColorStop(.55, "#39a7ff");
  gradient.addColorStop(1, "#ff5c7a");
  ctx.strokeStyle = gradient;
  ctx.lineWidth = 4;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  data.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)));
  ctx.stroke();

  data.forEach((v, i) => {
    ctx.fillStyle = v > 8 ? "#ff5c7a" : "#42e8c9";
    ctx.beginPath();
    ctx.arc(x(i), y(v), v > 8 ? 5 : 3.5, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.fillStyle = "rgba(237,247,255,.72)";
  ctx.font = "12px Segoe UI";
  ctx.fillText("2°C", 6, y(2) + 4);
  ctx.fillText("8°C max", 6, y(8) + 4);
}

function drawAllCharts() {
  drawChart("dashboardChart", state.chartData, 2, 10);
  drawChart("trackingChart", state.chartData, 2, 10);
  drawChart("quarantineChart", state.chartData.slice(5), 2, 10);
}

function initEvents() {
  $("#loginForm").addEventListener("submit", e => {
    e.preventDefault();
    $("#loginView").classList.add("hidden");
    $("#appView").classList.remove("hidden");
    renderAll();
    toast("Welcome to ColdChainRx Command Center");
  });

  $$(".nav-item").forEach(button => button.addEventListener("click", () => navigate(button.dataset.page)));
  $$('[data-page-jump]').forEach(button => button.addEventListener("click", () => navigate(button.dataset.pageJump)));

  $("#shipmentForm").addEventListener("submit", e => {
    e.preventDefault();
    const id = $("#shipmentId").value.trim() || "SH-2052";
    state.shipments.unshift({ id, medicine: "Influenza Vaccine / Rapid Insulin", status: "Prepared", eta: "Pending", type: "normal" });
    state.audit.unshift(["Now", "Warehouse Manager", "Shipment created", id, "Prepared"]);
    renderAll();
    toast(`${id} created and linked to sensor SEN-TMP-8842`);
  });

  $("#simulateReadingBtn").addEventListener("click", () => {
    const next = +(7 + Math.random() * 3.8).toFixed(1);
    state.chartData.push(next);
    if (state.chartData.length > 18) state.chartData.shift();
    if (next > 8) toast(`Unsafe reading detected: ${next}°C. Breach workflow ready.`);
    drawAllCharts();
  });

  $("#quarantineNowBtn").addEventListener("click", () => {
    const target = state.shipments.find(s => s.id === "SH-2048");
    if (target) { target.status = "Quarantined"; target.type = "quarantine"; target.eta = "Blocked"; }
    state.audit.unshift(["Now", "QA Officer", "Shipment quarantined", "SH-2048", "Pending QA"]);
    renderAll();
    toast("Shipment SH-2048 is now quarantined and blocked from receiving.");
  });

  $("#recordDecisionBtn").addEventListener("click", () => {
    const decision = $("#qaDecision").value;
    state.audit.unshift(["Now", "QA Officer", "QA decision recorded", "QC-118", decision]);
    renderAudit();
    toast(`QA decision recorded: ${decision}`);
  });

  $("#recallForm").addEventListener("submit", e => {
    e.preventDefault();
    $("#recallCount").textContent = "2";
    state.audit.unshift(["Now", "Supplier", "Recall issued", $("#recallBatch").value, $("#recallSeverity").value]);
    renderAudit();
    toast("Recall issued. Affected locations traced and notified.");
  });

  $("#generateReportBtn").addEventListener("click", () => toast("Compliance PDF generated and stored in secure report archive."));
  window.addEventListener("resize", drawAllCharts);
}

function renderAll() {
  renderShipments();
  renderAlerts();
  renderAffectedLocations();
  renderAudit();
  drawAllCharts();
}

initEvents();
