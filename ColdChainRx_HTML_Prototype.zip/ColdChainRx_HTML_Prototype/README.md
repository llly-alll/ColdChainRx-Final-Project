# ColdChainRx HTML Prototype

Open `index.html` in a browser. The prototype is built with plain HTML, CSS, and JavaScript and does not require internet access.

Suggested screenshots for the final report:

1. Login screen
2. Dashboard
3. Create shipment page
4. Shipment tracking page
5. Temperature breach center
6. Quarantine review page
7. Drug recall page
8. Reports page
9. Audit log page

Suggested demo flow:

1. Log in using the prefilled account.
2. Open Dashboard and capture the live network and metric cards.
3. Open Create Shipment and create SH-2052.
4. Open Tracking and capture telemetry chart.
5. Open Breach Center and click Quarantine Shipment.
6. Open Quarantine Review and record a QA decision.
7. Open Drug Recall and issue recall for VAC-24-AZ19.
8. Open Reports and generate report.
